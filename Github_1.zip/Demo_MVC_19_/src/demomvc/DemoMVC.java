
package demomvc;

public class DemoMVC {

    public static void main(String[] args) {
   
    }
    
}
