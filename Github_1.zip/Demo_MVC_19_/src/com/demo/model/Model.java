
package com.demo.model;

public class Model {
    
}
