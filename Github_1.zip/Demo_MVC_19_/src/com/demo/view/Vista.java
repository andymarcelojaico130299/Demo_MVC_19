
package com.demo.view;

public class Vista {
    
}
